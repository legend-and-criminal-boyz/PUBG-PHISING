red='\033[1;31m'
rset='\033[0m'
grn='\033[1;32m'
ylo='\033[1;33m'
blue='\033[1;34m'
cyan='\033[1;36m'
pink='\033[1;35m'
clear
echo " "
echo -e "$red------------$cyan[ Tool By Online Hacking  ]$red------------$rset"
echo " "
echo -e "$red-----------------$cyan> Facebook <$red--------------------$rset"
cat fbcracked.txt
echo " "
echo -e "$grn------------------$pink> Twitter <$grn-------------------$rset"
cat twcracked.txt
echo " "
echo -e "$ylo-------------------$grn> Gmail <$ylo--------------------$rset"
cat gmailcracked.txt
echo " "
echo -e "$cyan-----------------# All LoGS #----------------------$rset"
echo " "
exit
